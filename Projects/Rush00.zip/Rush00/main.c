void rush(int x, int y); 

int main(void)
{
    rush(15, 3);
    return (0);
}
